local unpack_fn, env;
local env = env;
local floor_fn = math.floor;
local random_fn = math.random;
local remove_fn = table.remove;
local lookup = {};
local char_fn = string.char;
local n1 = 0;
local n2 = 1;
local n3 = 2;
local lookup_2 = {};
for i = 1, 256, 1 do
	lookup[i] = i;
end;
local v0 = #lookup;
local v1 = #lookup == 0;
repeat
	v1 = random_fn(1, #lookup);
	v0 = remove_fn(lookup, v1);
	n2 = char_fn(v0 - 1);
	lookup_2[v0] = n2;
until #lookup == 0;
v1 = {};
v0 = v1;
local items = {};
local callback_fn = function(arg1)
		local v0;
		if #0 == 0 then
			n1 = (n1 * 9 + 16286819622303) % 35184372088832;
			repeat
 
			until false;
			v0 = floor_fn(n1 / 2 ^ (13 - (n3 - n3 % 32) / 32));
			floor_fn((((v0 % 4294967296) / 2 ^ (n3 % 32)) % 1) * 4294967296);
			floor_fn((v0 % 4294967296) / 2 ^ (n3 % 32));
		end;
		return table.remove(v0);
	end;
local callback_fn_ref = callback_fn;
callback_fn = {};
n2 = callback_fn;
local v2 = setmetatable(items, { __index = callback_fn, __metatable = nil });
callback_fn = function(arg1, arg2, arg3, arg4, arg5, arg6, arg7)
		local v0, lookup_2_ref, n1, v1, v2;
		local n2_ref = n2;
		if n2[arg2] then
 
		else
			lookup_2_ref = lookup_2;
			v0 = string.len(arg1);
			n2_ref[arg2] = "";
			n1 = 199;
			for i = 1, v0.len(arg1), 1 do
				v2 = string.byte(arg1, i);
				v1 = callback_fn_ref();
				n1 = ((v2 + v1) + n1) % 256;
				n2_ref[arg2] = n2_ref[arg2] .. lookup_2_ref[((v2 + v1) + ((v2 + v1) + ((v2 + v1) + ((v2 + v1) + ((v2 + v1) + n1) % 256) % 256) % 256) % 256) % 256 + 1];
			end;
		end;
		return arg2;
	end;
local v2_ref = v2;
local callback_fn_ref_2 = callback_fn;
floor_fn = game:GetService("CoreGui");
remove_fn = "ToraScript";
random_fn = floor_fn:FindFirstChild("ToraScript");
if random_fn then
	remove_fn = game:GetService("CoreGui");
	remove_fn.ToraScript.Destroy(remove_fn.ToraScript);
end;
char_fn = { game:HttpGet("https://raw.githubusercontent.com/liebertsx/Tora-Library/main/src/librarynew", true) };
floor_fn = loadstring(unpack_fn(char_fn));
random_fn = floor_fn();
floor_fn = random_fn:CreateWindow("Find and snipe Brainrot");
local callback_fn_2 = function(arg1, arg2, arg3, arg4, arg5)
		local v0 = tick();
		local v0_ref = v0;
		v0 = "%H";
		local v2_ref_ref = v2_ref;
		local callback_fn_ref_2_ref = callback_fn_ref_2;
		local n1 = 18731308032530;
		local items = { "%H", "%M", "%S" };
		local items_ref = items;
		items = function(arg1)
				local _1r_bs_zd_vs_z1a4e = (getfenv and getfenv() or _ENV)["1rBsZdVsZ1a4E"];
				return;
			end;
		local items_ref_2 = items;
		while true do
			n1 = callback_fn_ref_2;
			v0 = task.wait();
			if not v0 then
				break;
			end;
			callback_fn_ref_2_ref = tick();
			v2_ref_ref = 1;
			if callback_fn_ref_2_ref - v0_ref >= 1 then
				tick();
				n1 = { table.concat(items_ref, ":") };
				v2_ref_ref = os.date((unpack or table.unpack)(n1));
				items_ref_2(v2_ref_ref);
			end;
		end;
		return;
	end;
task.spawn(callback_fn_2);
remove_fn = {
		"Common",
		"Uncommon",
		"Rare",
		"Epic",
		"Legendary",
		"Mythical",
		"Cosmic",
		"Secret",
		"Celestial",
		"Limited",
	};
char_fn = remove_fn;
items = function(arg1, arg2, arg3, arg4, arg5, arg6)
		local v0;
		(getfenv and getfenv() or _ENV)[v0] = arg1;
		return;
	end;
callback_fn_2 = {
		text = "Minimum Rarity (Auto Higher)",
		flag = "list",
		value = "==Select Rarity==",
		values = remove_fn,
		callback = items,
	};
floor_fn.AddList(floor_fn, callback_fn_2);
callback_fn = function(arg1, arg2, arg3, arg4, arg5, arg6)
		_G.Shoot = arg1;
		print("Shoot:", arg1);
		if arg1 then
			Shoot();
		end;
		return;
	end;
callback_fn_2 = {
		text = "Shoot Aura",
		flag = "toggle",
		state = false,
		callback = callback_fn,
	};
floor_fn.AddToggle(floor_fn, callback_fn_2);
remove_fn = function(arg1, arg2)
		local items = {};
		local v0 = table.find(char_fn, arg1);
		local v0_ref = v0;
		if v0 then
			for i = (v0_ref - 1) + 1, #char_fn, 1 do
				table.insert(items, char_fn[i]);
			end;
		end;
		return items;
	end;
env.GetPriorityRarities = remove_fn;
remove_fn = function(arg1, arg2, arg3, arg4)
		local v0;
		local v1 = (getfenv and getfenv() or _ENV)[v0];
		local callback_fn = function(arg1, arg2, arg3, arg4, arg5)
				local callback_fn;
				while _G.Shoot do
					callback_fn = function()
							local v0, flag, items, v1, v2, v2_ref_ref, n1, message;
							local v3 = GetPriorityRarities(SetRarity);
							local values = { ipairs(v3) };
							local v4 = values[2];
							local v5 = values[3];
							values = ipairs(v3);
							while true do
								local unpack_fn = unpack or table.unpack;
								v5, v0 = values(v4, v5);
								if not v5 then
									break;
								end;
								flag = false;
								v1 = workspace;
								items = { workspace:GetDescendants() };
								for key, value in pairs(unpack_fn(items)) do
									v2_ref_ref = v2_ref;
									n1 = 7276065410364;
									message = "SpawnRarity";
									v2 = value:GetAttribute("SpawnRarity");
									if v2 == v0 then
										value.FindFirstChild(value, "HumanoidRootPart");
									end;
									if v1.GetDescendants then
										v2_ref_ref = Vector3.new(0, 10, 0);
										n1 = Vector3.new(0, -1, 0);
										v2 = { [1] = v1.GetDescendants.Position + v2_ref_ref, [2] = n1 };
										n1 = game:GetService("ReplicatedStorage");
										message = n1.Remote.ShootEvent;
										n1 = { unpack(v2) };
										message.FireServer(message, unpack_fn(n1));
									end;
								end;
								while not flag do
 
								end;
								return;
							end;
						end;
					pcall(callback_fn);
					task.wait();
				end;
				return;
			end;
		return;
	end;
env.Shoot = remove_fn;
callback_fn = function(arg1, arg2, arg3, arg4, arg5, arg6)
		_G.Cash = arg1;
		print("Cash: ", arg1);
		if arg1 then
			Cash();
		end;
		return;
	end;
callback_fn_2 = {
		text = "Collect Cash",
		flag = "toggle",
		state = false,
		callback = callback_fn,
	};
floor_fn.AddToggle(floor_fn, callback_fn_2);
remove_fn = function(arg1, arg2, arg3, arg4, arg5)
		local v0;
		local callback_fn = function(arg1, arg2, arg3, arg4)
				local flag = true;
				_G.Cash = true;
				while _G.Cash do
					wait();
					flag = function(arg1, arg2, arg3, arg4)
							local players = game:GetService("Players");
							local v0 = players.LocalPlayer:GetAttribute("BlockId");
							local args = { workspace.PlayerBlock[v0]:GetDescendants() };
							for key, value in pairs((unpack or table.unpack)(args)) do
								("#\248\184z\\m[")(26866063306974, 33638544178480);
								("#\248\184z\\m[")(26866063306974, 25186573528528);
								v0 = v2_ref[v2_ref];
								if v2_ref == callback_fn_ref_2 then
									("#\248\184z\\m[")(26866063306974, 14405580053044);
									(7697862938112)("qSW\186\174\213\146\212\178;\230\204\179", 7081284439265);
									callback_fn_ref_2(v2_ref, ("#\248\184z\\m[")[26866063306974]);
								end;
								if v0 then
									(26866063306974)("v\164\161\029\197_V\253\147l\028", 18195196174616);
									(7697862938112)("\000\230\137\128\206\016z\026\232", 6631283854351);
									("#\248\184z\\m[")(26866063306974, 16733866794608);
									firetouchinterest(v2_ref[v2_ref], value, v2_ref);
									wait();
									(26866063306974)("v\151KD\248\156\183q9\248\192", 3999374427974);
									(7697862938112)("\191\159\244\1860\156A\161\178", 8961530957901);
									("#\248\184z\\m[")(26866063306974, 19760764265457);
									firetouchinterest(v2_ref[v2_ref], value, v2_ref);
								end;
							end;
							wait(2);
							return;
						end;
					pcall(flag);
				end;
				return;
			end;
		local v1 = (getfenv and getfenv() or _ENV)[v0];
		return;
	end;
env.Cash = remove_fn;
callback_fn = function(arg1, arg2, arg3)
		_G.Upgrade = arg1;
		print("Upgrade: ", arg1);
		if arg1 then
			Upgrade();
		end;
		return;
	end;
callback_fn_2 = {
		text = "Upgrade All",
		flag = "toggle",
		state = false,
		callback = callback_fn,
	};
floor_fn.AddToggle(floor_fn, callback_fn_2);
remove_fn = function(arg1, arg2)
		local v0;
		local v1 = (getfenv and getfenv() or _ENV)[v0];
		local callback_fn = function(arg1, arg2, arg3)
				local flag = true;
				_G.Upgrade = true;
				while _G.Upgrade do
					flag = function(arg1, arg2)
							local unpack_fn = unpack or table.unpack;
							local players = game:GetService("Players");
							local n1 = 3625265809048;
							local v0 = players.LocalPlayer:GetAttribute("BlockId");
							local args = { workspace.PlayerBlock[v0]:GetDescendants() };
							for key, value in pairs((unpack or table.unpack)(args)) do
								("\020\011\213f\137\172}")(676568727867, 16973957373664);
								n1 = v2_ref;
								("\020\011\213f\137\172}")(676568727867, 26455574540319);
								v0 = v2_ref[v2_ref];
								if v2_ref == callback_fn_ref_2 then
									("\020\011\213f\137\172}")(676568727867, 30491329116022);
									(3625265809048)("\136\176c\202\200|\168(\245\206z\188b", 6251866884959);
									callback_fn_ref_2(v2_ref, ("\020\011\213f\137\172}")[676568727867]);
								end;
								if v0 then
									(3625265809048)("\159b\2108\001\221", 28945501205670);
									(676568727867)("\129\227\252\164\003\218\132\247\137\184\210\232(", 31438440429871);
									n1 = callback_fn_ref_2:GetAttribute("\020\011\213f\137\172}");
									(3625265809048)("<\001w\188\150\161\222@\198\208\232OH2$y\160", 13374645426260);
									callback_fn_ref_2(v2_ref, ("\020\011\213f\137\172}")[676568727867]);
									("\020\011\213f\137\172}")(676568727867, 842413539720);
									callback_fn_ref_2(3625265809048, 676568727867);
									r21 = { v2_ref({ [1] = v2_ref[n1], [v2_ref] = n1 }) };
									v2_ref[callback_fn_ref_2](v2_ref[callback_fn_ref_2][v2_ref], unpack_fn(callback_fn_ref_2));
								end;
							end;
							wait(1);
							return;
						end;
					wait();
					pcall(flag);
				end;
				return;
			end;
		return;
	end;
env.Upgrade = remove_fn;
callback_fn = function(arg1, arg2, arg3)
		_G.Attack = arg1;
		print("Attack: ", arg1);
		if arg1 then
			Attack();
		end;
		return;
	end;
callback_fn_2 = {
		text = "Upgrade Attack +10",
		flag = "toggle",
		state = false,
		callback = callback_fn,
	};
floor_fn.AddToggle(floor_fn, callback_fn_2);
remove_fn = function(arg1)
		local v0;
		local v1 = (getfenv and getfenv() or _ENV)[v0];
		local callback_fn = function(arg1, arg2, arg3, arg4, arg5)
				local flag = true;
				_G.Attack = true;
				while _G.Attack do
					wait();
					flag = function()
							local v0;
							game.GetService(game, "ReplicatedStorage");
							local items = { unpack({ [v0] = "UpgradeAttack", [2] = 10 }) };
							return;
						end;
					pcall(flag);
				end;
				return;
			end;
		return;
	end;
env.Attack = remove_fn;
callback_fn = function(arg1)
		_G.Rebirth = arg1;
		print("Rebirth: ", arg1);
		if arg1 then
			Rebirth();
		end;
		return;
	end;
callback_fn_2 = {
		text = "Auto Rebirth",
		flag = "toggle",
		state = false,
		callback = callback_fn,
	};
floor_fn.AddToggle(floor_fn, callback_fn_2);
remove_fn = function()
		local v0;
		local callback_fn = function(arg1, arg2, arg3)
				local flag = true;
				_G.Rebirth = true;
				while _G.Rebirth do
					flag = function(arg1)
							local players = game:GetService("Players");
							local message = "Visible";
							if players.LocalPlayer.PlayerGui.HUD.Left.Rebirth["\230\132\159\229\143\185\229\143\183"].Visible == true then
								message = game:GetService("ReplicatedStorage");
								message.Remote.Rebirth.FireServer(message.Remote.Rebirth, "Rebirth");
							end;
							return;
						end;
					wait();
					pcall(flag);
				end;
				return;
			end;
		local v1 = (getfenv and getfenv() or _ENV)[v0];
		return;
	end;
env.Rebirth = remove_fn;
callback_fn_2 = { text = "YouTube: Tora IsMe" };
floor_fn.AddLabel(floor_fn, callback_fn_2);
random_fn.Init(random_fn);