local unpack_fn, env;
local env = env;
local unpack_fn = unpack_fn;
local floor_fn = math.floor;
local random_fn = math.random;
local remove_fn = table.remove;
local char_fn = string.char;
local lookup = {};
local n1 = 0;
local n2 = 2;
local lookup_2 = {};
local n3 = 1;
for i = 1, 256, 1 do
	lookup[i] = i;
end;
local v0 = #lookup;
local v1 = #lookup == 0;
repeat
	v1 = random_fn(1, #lookup);
	v0 = remove_fn(lookup, v1);
	n3 = char_fn(v0 - 1);
	lookup_2[v0] = n3;
until #lookup == 0;
local callback_fn = function(arg1, arg2, arg3)
		local v0;
		if #0 == 0 then
			n1 = (n1 * 121 + 25824531918585) % 35184372088832;
			repeat
 
			until false;
			v0 = floor_fn(n1 / 2 ^ (13 - (n2 - n2 % 32) / 32));
			floor_fn((((v0 % 4294967296) / 2 ^ (n2 % 32)) % 1) * 4294967296);
			floor_fn((v0 % 4294967296) / 2 ^ (n2 % 32));
		end;
		return table.remove(v0);
	end;
local callback_fn_ref = callback_fn;
callback_fn = {};
n3 = callback_fn;
local items = { __index = callback_fn, __metatable = nil };
local v2 = setmetatable({}, items);
local v2_ref = v2;
callback_fn = function(arg1, arg2, arg3, arg4, arg5)
		local lookup_2_ref, v0, n1, v1, v2;
		local n3_ref = n3;
		if n3[arg2] then
 
		else
			lookup_2_ref = lookup_2;
			v0 = string.len(arg1);
			n3_ref[arg2] = "";
			n1 = 153;
			for i = 1, v0.len(arg1), 1 do
				v2 = string.byte(arg1, i);
				v1 = callback_fn_ref();
				n3_ref[arg2] = n3_ref[arg2] .. lookup_2_ref[(n3_ref[arg2] .. lookup_2_ref[((v2 + v1) + n1) % 256 + 1]) % 256 + 1];
			end;
		end;
		return arg2;
	end;
local callback_fn_ref_2 = callback_fn;
floor_fn = game:GetService("CoreGui");
remove_fn = "ToraScript";
random_fn = floor_fn:FindFirstChild("ToraScript");
if random_fn then
	remove_fn = game:GetService("CoreGui");
	remove_fn.ToraScript.Destroy(remove_fn.ToraScript);
end;
char_fn = { game:HttpGet("https://raw.githubusercontent.com/liebertsx/Tora-Library/main/src/librarynew", true) };
floor_fn = loadstring(unpack_fn(char_fn));
random_fn = floor_fn();
floor_fn = random_fn:CreateWindow("Hack Vault for Brainrots");
local callback_fn_2 = function(arg1, arg2, arg3, arg4, arg5)
		local v0 = tick();
		local v0_ref = v0;
		v0 = "%H";
		local v2_ref_ref = v2_ref;
		local callback_fn_ref_2_ref = callback_fn_ref_2;
		local n1 = 3796745914087;
		local items = { "%H", "%M", "%S" };
		local items_ref = items;
		items = function(arg1)
				return;
			end;
		local items_ref_2 = items;
		while true do
			n1 = callback_fn_ref_2;
			v0 = task.wait();
			if not v0 then
				break;
			end;
			callback_fn_ref_2_ref = tick();
			v2_ref_ref = 1;
			if callback_fn_ref_2_ref - v0_ref >= 1 then
				tick();
				n1 = { table.concat(items_ref, ":") };
				v2_ref_ref = os.date((unpack or table.unpack)(n1));
				items_ref_2(v2_ref_ref);
			end;
		end;
		return;
	end;
task.spawn(callback_fn_2);
char_fn = nil;
lookup_2 = { workspace.Plots:GetDescendants() };
for key, value in pairs(unpack_fn(lookup_2)) do
	(29758355158561)("+\188j\183", 3760893183703);
	items = (29758355158561)("\218rS\150\213\014\1322\169\140=\215\129", 3447082796613);
	lookup_2 = v2_ref;
	if callback_fn_ref_2 == ("V\238\229\154@")[items] then
		(29758355158561)("O]$\210\196\188\182", 15033421241176);
	end;
	if lookup_2 then
		callback_fn_ref_2(29758355158561, 31320984418552);
		callback_fn_ref_2(29758355158561, 16505408347653);
	end;
end;
n3 = function(arg1, arg2, arg3, arg4, arg5)
		_G.Farm = arg1;
		print("Farm: ", arg1);
		if arg1 then
			Farm();
		end;
		return;
	end;
callback_fn_2 = {
		text = "LastZone Farm",
		flag = "toggle",
		state = false,
		callback = n3,
	};
floor_fn.AddToggle(floor_fn, callback_fn_2);
remove_fn = function()
		local v0;
		local callback_fn = function(arg1, arg2)
				local v0 = workspace.Break_Map.Misc.Building.Zones.Zone22.Pillar.Pillar:GetPivot("WorldPivot");
				game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = v0;
				local flag = true;
				_G.Farm = true;
				while _G.Farm do
					flag = function(arg1, arg2)
							local n1 = 29261570635065;
							local args = { workspace.EntitiesFolder:GetChildren() };
							for key, value in pairs((unpack or table.unpack)(args)) do
								while true do
									value:GetAttribute("EntitiesFolder");
									if v2_ref == "EntitiesFolder" then
										break;
									end;
								end;
								value:GetPivot("WorldPivot");
								pairs[v2_ref] = callback_fn_ref_2;
								wait(.2);
								n1 = value:FindFirstChildOfClass("MeshPart");
								fireproximityprompt(n1.TakeBrainrotPrompt);
								wait(.2);
								n1 = char_fn:GetPivot("WorldPivot");
								pairs[v2_ref] = n1;
								wait(1);
								return;
							end;
						end;
					wait();
					pcall(flag);
				end;
				return;
			end;
		local v1 = (getfenv and getfenv() or _ENV)[v0];
		return;
	end;
env.Farm = remove_fn;
n3 = function(arg1, arg2, arg3, arg4, arg5)
		_G.Cash = arg1;
		print("Cash: ", arg1);
		if arg1 then
			Cash();
		end;
		return;
	end;
callback_fn_2 = {
		text = "Collect Cash",
		flag = "toggle",
		state = false,
		callback = n3,
	};
floor_fn.AddToggle(floor_fn, callback_fn_2);
remove_fn = function(arg1, arg2, arg3, arg4, arg5)
		local v0;
		local callback_fn = function(arg1)
				local flag = true;
				_G.Cash = true;
				while _G.Cash do
					wait();
					flag = function(arg1)
							local env = getfenv and getfenv() or _ENV;
							local args = { char_fn.Floors:GetDescendants() };
							for key, value in pairs((unpack or table.unpack)(args)) do
								if value["\005W\161\0051,"] == "\005W\161\0051," then
									("\005W\161\0051,")(("\005W\161\0051,")[15704310389904], 15704310389904);
								end;
								if v2_ref then
									env[v2_ref](callback_fn_ref_2, value, 0);
									env[v2_ref]();
									env[v2_ref](callback_fn_ref_2, value, 1);
								end;
							end;
							wait(2);
							return;
						end;
					pcall(flag);
				end;
				return;
			end;
		local v1 = (getfenv and getfenv() or _ENV)[v0];
		return;
	end;
env.Cash = remove_fn;
n3 = function(arg1, arg2, arg3, arg4, arg5, arg6)
		_G.Upgrade = arg1;
		print("Upgrade: ", arg1);
		if arg1 then
			Upgrade();
		end;
		return;
	end;
callback_fn_2 = {
		text = "Upgrade All",
		flag = "toggle",
		state = false,
		callback = n3,
	};
floor_fn.AddToggle(floor_fn, callback_fn_2);
remove_fn = function(arg1, arg2, arg3)
		local v0;
		local callback_fn = function(arg1, arg2)
				local flag = true;
				_G.Upgrade = true;
				while _G.Upgrade do
					wait();
					flag = function(arg1)
							local env = getfenv and getfenv() or _ENV;
							local unpack_fn = unpack or table.unpack;
							local n1, callback_fn_ref_2_ref, replicated_storage;
							local args = { char_fn.Floors:GetDescendants() };
							for key, value in pairs((unpack or table.unpack)(args)) do
								n1 = 6300013972341;
								callback_fn_ref_2_ref = callback_fn_ref_2;
								if value["\"\129\023j\224\179"] == "\"\129\023j\224\179" then
									("\"\129\023j\224\179")(("\"\129\023j\224\179")[3701078623931], 3701078623931);
								end;
								if v2_ref then
									(3701078623931)("\'@\165\154\138Z", 6414534380459);
									("\"\129\023j\224\179")("\223[\146\178", 29051333965016);
									callback_fn_ref_2_ref = { (3701078623931)(v2_ref, "%d+") };
									env["\"\129\023j\224\179"](unpack_fn(callback_fn_ref_2_ref));
									(3701078623931)(value.Parent.Parent.Name);
									replicated_storage = game:GetService("ReplicatedStorage");
									n1 = { unpack(3701078623931) };
									replicated_storage.Utilities.TypedRemote.UpgradeStand.FireServer(replicated_storage.Utilities.TypedRemote.UpgradeStand, unpack_fn(n1));
								end;
							end;
							wait(1);
							return;
						end;
					pcall(flag);
				end;
				return;
			end;
		local v1 = (getfenv and getfenv() or _ENV)[v0];
		return;
	end;
env.Upgrade = remove_fn;
n3 = function(arg1, arg2, arg3, arg4, arg5)
		_G.Hacking = arg1;
		print("Hacking: ", arg1);
		if arg1 then
			Hacking();
		end;
		return;
	end;
callback_fn_2 = {
		text = "Hacking Upgrade +10",
		flag = "toggle",
		state = false,
		callback = n3,
	};
floor_fn.AddToggle(floor_fn, callback_fn_2);
remove_fn = function(arg1, arg2, arg3, arg4)
		local v0;
		local v1 = (getfenv and getfenv() or _ENV)[v0];
		local callback_fn = function(arg1, arg2, arg3)
				local flag = true;
				_G.Hacking = true;
				while _G.Hacking do
					flag = function(arg1, arg2, arg3, arg4, arg5)
							local v0;
							game.GetService(game, "ReplicatedStorage");
							local items = { unpack({ [v0] = "HackingUpgrade", [2] = 10 }) };
							return;
						end;
					wait();
					pcall(flag);
				end;
				return;
			end;
		return;
	end;
env.Hacking = remove_fn;
v0 = function(arg1, arg2, arg3, arg4)
		local n1 = 15276474227657;
		local args = { workspace.EntitiesFolder:GetDescendants() };
		for key, value in pairs((unpack or table.unpack)(args)) do
			if value.Name == "NameLabel" then
				game.GetService(game, "Players");
			end;
			while not v2_ref do
 
			end;
			n1 = callback_fn_ref_2:GetPivot("WorldPivot");
			pairs[v2_ref] = n1;
			wait(.2);
			("\234\021\\N>\141z\246\241\151\216\143\213c").Parent:FindFirstChildOfClass("MeshPart");
			fireproximityprompt(("\234\021\\N>\141z\246\241\151\216\143\213c").TakeBrainrotPrompt);
			wait(.2);
			n1 = char_fn:GetPivot("WorldPivot");
			pairs[v2_ref] = n1;
			return;
		end;
	end;
callback_fn_2 = { text = "Rebirth Requirement", flag = "button", callback = v0 };
floor_fn.AddButton(floor_fn, callback_fn_2);
v0 = function()
		local v0;
		local v1 = CFrame.new(-2512, 14, -711);
		v0.HumanoidRootPart[v0] = v1;
		return;
	end;
callback_fn_2 = { text = "Goto LastZone", flag = "button", callback = v0 };
floor_fn.AddButton(floor_fn, callback_fn_2);
callback_fn_2 = { text = "YouTube: Tora IsMe" };
floor_fn.AddLabel(floor_fn, callback_fn_2);
random_fn.Init(random_fn);