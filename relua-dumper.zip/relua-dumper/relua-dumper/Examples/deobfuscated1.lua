local unpack_fn, env;
local env = env;
local unpack_fn = unpack_fn;
local lookup = {};
local floor_fn = math.floor;
local random_fn = math.random;
local remove_fn = table.remove;
local char_fn = string.char;
local n1 = 0;
local n2 = 2;
local lookup_2 = {};
local n3 = 1;
for i = 1, 256, 1 do
	lookup[i] = i;
end;
local v0 = #lookup;
local v1 = #lookup == 0;
repeat
	v1 = random_fn(1, #lookup);
	v0 = remove_fn(lookup, v1);
	n3 = char_fn(v0 - 1);
	lookup_2[v0] = n3;
until #lookup == 0;
local callback_fn = function(arg1, arg2, arg3, arg4)
		local v0;
		if #0 == 0 then
			n1 = (n1 * 81 + 26376967598073) % 35184372088832;
			repeat
 
			until false;
			v0 = floor_fn(n1 / 2 ^ (13 - (n2 - n2 % 32) / 32));
			floor_fn((((v0 % 4294967296) / 2 ^ (n2 % 32)) % 1) * 4294967296);
			floor_fn((v0 % 4294967296) / 2 ^ (n2 % 32));
		end;
		return table.remove(v0);
	end;
local callback_fn_ref = callback_fn;
callback_fn = {};
n3 = callback_fn;
local v2 = setmetatable({}, { __index = callback_fn, __metatable = nil });
callback_fn = function(arg1, arg2, arg3, arg4, arg5)
		local lookup_2_ref, v0, n1, v1, v2;
		local n3_ref = n3;
		if n3[arg2] then
 
		else
			lookup_2_ref = lookup_2;
			v0 = string.len(arg1);
			n3_ref[arg2] = "";
			n1 = 154;
			for i = 1, v0.len(arg1), 1 do
				v2 = string.byte(arg1, i);
				v1 = callback_fn_ref();
				n3_ref[arg2] = n3_ref[arg2] .. lookup_2_ref[((v2 + v1) + n1) % 256 + 1];
			end;
		end;
		return arg2;
	end;
local v2_ref = v2;
floor_fn = game:GetService("CoreGui");
remove_fn = "ToraScript";
random_fn = floor_fn:FindFirstChild("ToraScript");
if random_fn then
	remove_fn = game:GetService("CoreGui");
	remove_fn.ToraScript.Destroy(remove_fn.ToraScript);
end;
char_fn = { game:HttpGet("https://raw.githubusercontent.com/liebertsx/Tora-Library/main/src/librarynew", true) };
floor_fn = loadstring(unpack_fn(char_fn));
random_fn = floor_fn();
floor_fn = random_fn:CreateWindow("Smack the Brainrots");
v0 = function(arg1, arg2)
		local v0;
		local v1 = (getfenv and getfenv() or _ENV)[v0];
		v1[v0] = arg1;
		return;
	end;
char_fn = {
		text = "Steal Brainrots",
		flag = "toggle",
		state = false,
		callback = v0,
	};
floor_fn.AddToggle(floor_fn, char_fn);
char_fn = game:GetService("ReplicatedStorage");
local pick_upbrainrot = char_fn.Network.PickUpbrainrot;
lookup_2 = game;
lookup = { game:GetDescendants() };
for key, value in pairs(unpack_fn(lookup)) do
	v0 = v2_ref;
	lookup = value:IsA(lookup_2.GetDescendants);
	if lookup then
		v0 = function(...)
				local unpack_fn = unpack or table.unpack;
				local argv = { ... };
				local items = { select(1, (unpack or table.unpack)(argv)) };
				local n1 = 11741324416347;
				local v2_ref_ref = v2_ref;
				if not _G.Hatch then
					return;
				else
					v2_ref_ref = { unpack_fn(items) };
					for _, value in ipairs(v2_ref_ref) do
						while true do
							n1 = typeof(value);
							if n1 == "number" then
								break;
							end;
						end;
						pick_upbrainrot.FireServer(pick_upbrainrot, value);
						return;
					end;
				end;
			end;
		lookup_2.GetDescendants(value[lookup_2.GetDescendants], v0);
	end;
end;
n3 = function(arg1, arg2, arg3, arg4)
		_G.Strength = arg1;
		print("Strength: ", arg1);
		if arg1 then
			Strength();
		end;
		return;
	end;
n1 = {
		text = "Claim Strength",
		flag = "toggle",
		state = false,
		callback = n3,
	};
floor_fn.AddToggle(floor_fn, n1);
remove_fn = function(arg1, arg2, arg3)
		local v0;
		local callback_fn = function()
				local flag = true;
				_G.Strength = true;
				while _G.Strength do
					flag = function()
							game.GetService(game, "ReplicatedStorage");
							return;
						end;
					wait();
					pcall(flag);
				end;
				return;
			end;
		local v1 = (getfenv and getfenv() or _ENV)[v0];
		return;
	end;
env.Strength = remove_fn;
n3 = function(arg1, arg2, arg3, arg4, arg5)
		_G.Cash = arg1;
		print("Cash: ", arg1);
		if arg1 then
			Cash();
		end;
		return;
	end;
n1 = {
		text = "Collect Cash",
		flag = "toggle",
		state = false,
		callback = n3,
	};
floor_fn.AddToggle(floor_fn, n1);
remove_fn = function(arg1, arg2, arg3)
		local callback_fn = function(arg1, arg2, arg3, arg4)
				local flag = true;
				_G.Cash = true;
				while _G.Cash do
					wait();
					flag = function(arg1, arg2)
							local items, replicated_storage, items_ref;
							for i = 1, 10, 1 do
								items = { [1] = i };
								items_ref = items;
								replicated_storage = game:GetService("ReplicatedStorage");
								items = replicated_storage.Network.ClaimPlacementIncome;
								replicated_storage = { unpack(items_ref) };
								items.FireServer(items, (unpack or table.unpack)(replicated_storage));
								wait(.2);
							end;
							return;
						end;
					pcall(flag);
				end;
				return;
			end;
		return;
	end;
env.Cash = remove_fn;
n3 = function(arg1, arg2, arg3, arg4)
		_G.Upgrade = arg1;
		print("Upgrade: ", arg1);
		if arg1 then
			Upgrade();
		end;
		return;
	end;
n1 = {
		text = "Auto Upgrade",
		flag = "toggle",
		state = false,
		callback = n3,
	};
floor_fn.AddToggle(floor_fn, n1);
remove_fn = function(arg1, arg2)
		local v0;
		local v1 = (getfenv and getfenv() or _ENV)[v0];
		local callback_fn = function(arg1)
				local flag = true;
				_G.Upgrade = true;
				while _G.Upgrade do
					flag = function()
							local items, items_ref, replicated_storage;
							for i = 1, 10, 1 do
								items = { [1] = i };
								items_ref = items;
								replicated_storage = game:GetService("ReplicatedStorage");
								items = replicated_storage.Network.UpgradePlacement;
								replicated_storage = { unpack(items_ref) };
								items.FireServer(items, (unpack or table.unpack)(replicated_storage));
								wait(.2);
							end;
							return;
						end;
					wait();
					pcall(flag);
				end;
				return;
			end;
		return;
	end;
env.Upgrade = remove_fn;
n1 = { text = "YouTube: Tora IsMe" };
floor_fn.AddLabel(floor_fn, n1);
random_fn.Init(random_fn);