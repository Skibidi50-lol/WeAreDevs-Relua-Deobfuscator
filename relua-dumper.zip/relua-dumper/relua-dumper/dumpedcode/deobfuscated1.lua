local unpack_fn, env;
local env = env;
local floor_fn = math.floor;
local random_fn = math.random;
local remove_fn = table.remove;
local char_fn = string.char;
local lookup = {};
local n1 = 0;
local n2 = 2;
local lookup_2 = {};
local n3 = 1;
for i = 1, 256, 1 do
	lookup[i] = i;
end;
local v0 = #lookup;
local v1 = #lookup == 0;
repeat
	v1 = random_fn(1, #lookup);
	v0 = remove_fn(lookup, v1);
	n3 = char_fn(v0 - 1);
	lookup_2[v0] = n3;
until #lookup == 0;
v1 = {};
v0 = v1;
local callback_fn = function()
		local v0;
		if #0 == 0 then
			n1 = (n1 * 81 + 10496615256855) % 35184372088832;
			repeat
 
			until false;
			v0 = floor_fn(n1 / 2 ^ (13 - (n2 - n2 % 32) / 32));
			floor_fn((((v0 % 4294967296) / 2 ^ (n2 % 32)) % 1) * 4294967296);
			floor_fn((v0 % 4294967296) / 2 ^ (n2 % 32));
		end;
		return table.remove(v0);
	end;
local callback_fn_ref = callback_fn;
callback_fn = {};
n3 = callback_fn;
local v2 = setmetatable({}, { __index = callback_fn, __metatable = nil });
callback_fn = function(arg1, arg2)
		local lookup_2_ref, v0, n1, v1, v2;
		local n3_ref = n3;
		if n3[arg2] then
 
		else
			lookup_2_ref = lookup_2;
			v0 = string.len(arg1);
			n3_ref[arg2] = "";
			n1 = 2;
			for i = 1, v0.len(arg1), 1 do
				v2 = string.byte(arg1, i);
				v1 = callback_fn_ref();
				n3_ref[arg2] = n3_ref[arg2] .. lookup_2_ref[(n3_ref[arg2] .. lookup_2_ref[((v2 + v1) + n1) % 256 + 1]) % 256 + 1];
			end;
		end;
		return arg2;
	end;
local v2_ref = v2;
local callback_fn_ref_2 = callback_fn;
floor_fn = game:GetService("CoreGui");
remove_fn = "ToraScript";
random_fn = floor_fn:FindFirstChild("ToraScript");
if random_fn then
	remove_fn = game:GetService("CoreGui");
	remove_fn.ToraScript.Destroy(remove_fn.ToraScript);
end;
char_fn = { game:HttpGet("https://raw.githubusercontent.com/liebertsx/Tora-Library/main/src/librarynew", true) };
floor_fn = loadstring(unpack_fn(char_fn));
random_fn = floor_fn();
floor_fn = random_fn:CreateWindow("+1 Strength Per Click");
local callback_fn_2 = function()
		local v0 = tick();
		local v0_ref = v0;
		v0 = "%H";
		local v2_ref_ref = v2_ref;
		local callback_fn_ref_2_ref = callback_fn_ref_2;
		local n1 = 17686797393964;
		local items = { "%H", "%M", "%S" };
		local items_ref = items;
		items = function(arg1, arg2, arg3, arg4, arg5)
				return;
			end;
		local items_ref_2 = items;
		while true do
			n1 = callback_fn_ref_2;
			v0 = task.wait();
			if not v0 then
				break;
			end;
			callback_fn_ref_2_ref = tick();
			v2_ref_ref = 1;
			if callback_fn_ref_2_ref - v0_ref >= 1 then
				tick();
				n1 = { table.concat(items_ref, ":") };
				v2_ref_ref = os.date((unpack or table.unpack)(n1));
				items_ref_2(v2_ref_ref);
			end;
		end;
		return;
	end;
task.spawn(callback_fn_2);
lookup = function(arg1, arg2, arg3, arg4)
		game.GetService(game, "ReplicatedStorage");
		return;
	end;
char_fn = { text = "Inf Wins (Break Game)", flag = "button", callback = lookup };
floor_fn.AddButton(floor_fn, char_fn);
v0 = function(arg1, arg2, arg3, arg4, arg5, arg6)
		_G.Train = arg1;
		print("Train: ", arg1);
		if arg1 then
			Train();
		end;
		return;
	end;
char_fn = {
		text = "Auto Train",
		flag = "toggle",
		state = false,
		callback = v0,
	};
floor_fn.AddToggle(floor_fn, char_fn);
remove_fn = function(arg1, arg2, arg3, arg4)
		local v0;
		local callback_fn = function(arg1, arg2)
				local flag = true;
				_G.Train = true;
				while _G.Train do
					flag = function(arg1, arg2)
							game.GetService(game, "ReplicatedStorage");
							return;
						end;
					wait();
					pcall(flag);
				end;
				return;
			end;
		local v1 = (getfenv and getfenv() or _ENV)[v0];
		return;
	end;
env.Train = remove_fn;
v0 = function(arg1)
		_G.Damage = arg1;
		print("Damage: ", arg1);
		if arg1 then
			Damage();
		end;
		return;
	end;
char_fn = {
		text = "Auto Push",
		flag = "toggle",
		state = false,
		callback = v0,
	};
floor_fn.AddToggle(floor_fn, char_fn);
remove_fn = function(arg1, arg2, arg3, arg4)
		local v0;
		local callback_fn = function(arg1, arg2, arg3)
				local flag = true;
				_G.Damage = true;
				while _G.Damage do
					flag = function(arg1)
							game.GetService(game, "ReplicatedStorage");
							return;
						end;
					wait();
					pcall(flag);
				end;
				return;
			end;
		local v1 = (getfenv and getfenv() or _ENV)[v0];
		return;
	end;
env.Damage = remove_fn;
char_fn = { text = "YouTube: Tora IsMe" };
floor_fn.AddLabel(floor_fn, char_fn);
random_fn.Init(random_fn);