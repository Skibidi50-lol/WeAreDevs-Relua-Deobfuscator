local unpack_fn, env;
local env = env;
local lookup = {};
local floor_fn = math.floor;
local random_fn = math.random;
local remove_fn = table.remove;
local char_fn = string.char;
local n1 = 0;
local n2 = 2;
local lookup_2 = {};
local n3 = 1;
for i = 1, 256, 1 do
	lookup[i] = i;
end;
local v0 = #lookup;
local v1 = #lookup == 0;
repeat
	v1 = random_fn(1, #lookup);
	v0 = remove_fn(lookup, v1);
	n3 = char_fn(v0 - 1);
	lookup_2[v0] = n3;
until #lookup == 0;
v1 = {};
v0 = v1;
local callback_fn = function(arg1, arg2, arg3, arg4, arg5)
		local v0;
		if #0 == 0 then
			n1 = (n1 * 161 + 1337024479855) % 35184372088832;
			repeat
 
			until false;
			v0 = floor_fn(n1 / 2 ^ (13 - (n2 - n2 % 32) / 32));
			floor_fn((((v0 % 4294967296) / 2 ^ (n2 % 32)) % 1) * 4294967296);
			floor_fn((v0 % 4294967296) / 2 ^ (n2 % 32));
		end;
		return table.remove(v0);
	end;
local callback_fn_ref = callback_fn;
callback_fn = {};
n3 = callback_fn;
local v2 = setmetatable({}, { __index = callback_fn, __metatable = nil });
callback_fn = function(arg1, arg2)
		local v0, lookup_2_ref, n1, v1, v2;
		local n3_ref = n3;
		if n3[arg2] then
 
		else
			lookup_2_ref = lookup_2;
			v0 = string.len(arg1);
			n3_ref[arg2] = "";
			n1 = 95;
			for i = 1, v0.len(arg1), 1 do
				v2 = string.byte(arg1, i);
				v1 = callback_fn_ref();
				n3_ref[arg2] = n3_ref[arg2] .. lookup_2_ref[(n3_ref[arg2] .. lookup_2_ref[((v2 + v1) + n1) % 256 + 1]) % 256 + 1];
			end;
		end;
		return arg2;
	end;
local v2_ref = v2;
local callback_fn_ref_2 = callback_fn;
floor_fn = game:GetService("CoreGui");
remove_fn = "ToraScript";
random_fn = floor_fn:FindFirstChild("ToraScript");
if random_fn then
	remove_fn = game:GetService("CoreGui");
	remove_fn.ToraScript.Destroy(remove_fn.ToraScript);
end;
char_fn = { game:HttpGet("https://raw.githubusercontent.com/liebertsx/Tora-Library/main/src/librarynew", true) };
floor_fn = loadstring(unpack_fn(char_fn));
random_fn = floor_fn();
floor_fn = random_fn:CreateWindow("Pickaxe Tycoon");
local callback_fn_2 = function()
		local v0 = tick();
		local v0_ref = v0;
		v0 = "%H";
		local v2_ref_ref = v2_ref;
		local callback_fn_ref_2_ref = callback_fn_ref_2;
		local n1 = 14259492198896;
		local items = { "%H", "%M", "%S" };
		local items_ref = items;
		items = function(arg1, arg2, arg3, arg4)
				return;
			end;
		local items_ref_2 = items;
		while true do
			n1 = callback_fn_ref_2;
			v0 = task.wait();
			if not v0 then
				break;
			end;
			callback_fn_ref_2_ref = tick();
			v2_ref_ref = 1;
			if callback_fn_ref_2_ref - v0_ref >= 1 then
				tick();
				n1 = { table.concat(items_ref, ":") };
				v2_ref_ref = os.date((unpack or table.unpack)(n1));
				items_ref_2(v2_ref_ref);
			end;
		end;
		return;
	end;
task.spawn(callback_fn_2);
v0 = function(arg1, arg2, arg3, arg4, arg5)
		_G.Collect = arg1;
		print("Collect: ", arg1);
		if arg1 then
			Collect();
		end;
		return;
	end;
char_fn = {
		text = "Auto Collect",
		flag = "toggle",
		state = false,
		callback = v0,
	};
floor_fn.AddToggle(floor_fn, char_fn);
remove_fn = function(arg1, arg2, arg3)
		local v0;
		local v1 = (getfenv and getfenv() or _ENV)[v0];
		local callback_fn = function(arg1)
				local flag = true;
				_G.Collect = true;
				while _G.Collect do
					flag = function(arg1, arg2)
							local unpack_fn = unpack or table.unpack;
							local v0;
							local args = { workspace:GetChildren() };
							for key, value in pairs((unpack or table.unpack)(args)) do
								v0 = pairs(value.Name, "Loot");
								if v0 then
									pairs.CFrame = game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame;
								end;
							end;
							local items = { workspace:GetChildren() };
							for key, value in pairs(unpack_fn(items)) do
								pairs(value.Name, "Chest");
								if workspace.GetChildren then
									pairs[workspace.GetChildren] = game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame;
								end;
							end;
							wait(1);
							return;
						end;
					wait();
					pcall(flag);
				end;
				return;
			end;
		return;
	end;
env.Collect = remove_fn;
v0 = function(arg1, arg2)
		_G.Deposit = arg1;
		print("Deposit: ", arg1);
		if arg1 then
			Deposit();
		end;
		return;
	end;
char_fn = {
		text = "Auto Deposit",
		flag = "toggle",
		state = false,
		callback = v0,
	};
floor_fn.AddToggle(floor_fn, char_fn);
remove_fn = function(arg1)
		local v0;
		local v1 = (getfenv and getfenv() or _ENV)[v0];
		local callback_fn = function(arg1)
				local flag = true;
				_G.Deposit = true;
				while _G.Deposit do
					flag = function(arg1, arg2)
							local players = game:GetService("Players");
							players.LocalPlayer.GetAttribute(players.LocalPlayer, "assignedPlot");
							players = game:GetService("Players");
							players.LocalPlayer.GetAttribute(players.LocalPlayer, "assignedPlot");
							return;
						end;
					wait();
					pcall(flag);
				end;
				return;
			end;
		return;
	end;
env.Deposit = remove_fn;
v0 = function(arg1)
		_G.Cash = arg1;
		print("Cash: ", arg1);
		if arg1 then
			Cash();
		end;
		return;
	end;
char_fn = {
		text = "Collect Cash",
		flag = "toggle",
		state = false,
		callback = v0,
	};
floor_fn.AddToggle(floor_fn, char_fn);
remove_fn = function(arg1, arg2, arg3, arg4, arg5)
		local callback_fn = function(arg1, arg2)
				local flag = true;
				_G.Cash = true;
				while _G.Cash do
					flag = function(arg1)
							local players = game:GetService("Players");
							players.LocalPlayer.GetAttribute(players.LocalPlayer, "assignedPlot");
							players = game:GetService("Players");
							players.LocalPlayer.GetAttribute(players.LocalPlayer, "assignedPlot");
							return;
						end;
					wait();
					pcall(flag);
				end;
				return;
			end;
		return;
	end;
env.Cash = remove_fn;
v0 = function(arg1, arg2, arg3, arg4)
		_G.Second = arg1;
		print("Second: ", arg1);
		if arg1 then
			Second();
		end;
		return;
	end;
char_fn = {
		text = "Auto Per Second",
		flag = "toggle",
		state = false,
		callback = v0,
	};
floor_fn.AddToggle(floor_fn, char_fn);
remove_fn = function(arg1, arg2)
		local v0;
		local callback_fn = function(arg1, arg2, arg3)
				local flag = true;
				_G.Second = true;
				while _G.Second do
					wait();
					flag = function(arg1, arg2)
							local players = game:GetService("Players");
							players.LocalPlayer.GetAttribute(players.LocalPlayer, "assignedPlot");
							players = game:GetService("Players");
							players.LocalPlayer.GetAttribute(players.LocalPlayer, "assignedPlot");
							return;
						end;
					pcall(flag);
				end;
				return;
			end;
		local v1 = (getfenv and getfenv() or _ENV)[v0];
		return;
	end;
env.Second = remove_fn;
v0 = function(arg1, arg2, arg3, arg4)
		_G.Buy = arg1;
		print("Buy: ", arg1);
		if arg1 then
			Buy();
		end;
		return;
	end;
char_fn = {
		text = "Auto Buy & Merge",
		flag = "toggle",
		state = false,
		callback = v0,
	};
floor_fn.AddToggle(floor_fn, char_fn);
remove_fn = function(arg1, arg2, arg3, arg4, arg5)
		local v0;
		local callback_fn = function(arg1, arg2, arg3)
				local flag = true;
				_G.Buy = true;
				while _G.Buy do
					flag = function(arg1, arg2, arg3, arg4)
							local env = getfenv and getfenv() or _ENV;
							local players = game:GetService("Players");
							local v0 = players.LocalPlayer:GetAttribute("assignedPlot");
							local args = { workspace.Plots[v0].Buttons:GetDescendants() };
							for key, value in pairs((unpack or table.unpack)(args)) do
								("\211T\188\232\159L(")("h\244\234\202", "=\181\026\031\016\251\232g\233e\139\145");
								("\211T\188\232\159L(")("+\141\0141\161I", "=\181\026\031\016\251\232g\233e\139\145");
								if v2_ref == callback_fn_ref_2 then
									(17050648960771)("\227d\229y\147U\130", 2244548297749);
									(25681227427510)("\020Z\140\158\205\1729\185\189\215n", 1171701957153);
									("=\181\026\031\016\251\232g\233e\139\145")(17050648960771, 20589784999283);
									callback_fn_ref_2(25681227427510, 17050648960771);
									env[v2_ref](callback_fn_ref_2, value, 0);
									env[v2_ref]();
									(17050648960771)("ur\251\210&\161\252", 3485334521430);
									(25681227427510)("\214\131t\002\248\167\031\231\004]&", 2601104934075);
									("=\181\026\031\016\251\232g\233e\139\145")(17050648960771, 7270820138297);
									callback_fn_ref_2(25681227427510, 17050648960771);
									env[v2_ref](callback_fn_ref_2, value, 1);
								end;
							end;
							wait(1);
							return;
						end;
					wait();
					pcall(flag);
				end;
				return;
			end;
		local v1 = (getfenv and getfenv() or _ENV)[v0];
		return;
	end;
env.Buy = remove_fn;
char_fn = { text = "YouTube: Tora IsMe" };
floor_fn.AddLabel(floor_fn, char_fn);
random_fn.Init(random_fn);